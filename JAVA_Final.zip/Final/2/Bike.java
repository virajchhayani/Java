public class Bike extends Vehicle {
    @Override
    public void run() {
        System.out.println("Bike is running");
    }
}