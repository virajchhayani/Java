public class Maruti extends Car {
    public void accelerate() {
        System.out.println("Maruti accelerating");
    }

    public void brake() {
        System.out.println("Maruti braking");
    }
}
